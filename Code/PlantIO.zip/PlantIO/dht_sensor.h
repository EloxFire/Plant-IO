#include "DHT.h"//DHT sensor library
#include <DHT_U.h> //Adafruit sensor library
DHT dht(D2, DHT11);

float currentTempDHT, currentHumidityDHT;

void setupDHT(){
  Serial.println("Capteur DHT11 prêt !");
  dht.begin();
}

//Loop de récupération des données de température du DHT11
void getDHTTemp(){
  currentTempDHT = dht.readTemperature();
  Serial.print("Température actuelle : ");
  Serial.print(currentTempDHT);
  Serial.print("°C\n");
}

//Loop de récupération des données d'humidité du DHT11
void getDHTHumidity(){
  currentHumidityDHT = dht.readHumidity();
  Serial.print("Humidité actuelle : ");
  Serial.print(currentHumidityDHT);
  Serial.print("%\n");
}
