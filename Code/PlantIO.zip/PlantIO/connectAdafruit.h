//LIBRARIES
#include <ESP8266WiFi.h>
#include "Adafruit_MQTT.h"
#include "Adafruit_MQTT_Client.h"

//WIFI
//#define WLAN_SSID       "Bbox-4CF52CD9_EXT_2.4"
//#define WLAN_PASS       "WifiAvagliano"
#define WLAN_SSID       "YNOVAIX IOT"
#define WLAN_PASS       "9xUNb8mk7Vs3A3Y"

//ADAFRUIT IO
#define AIO_SERVER      "io.adafruit.com"
#define AIO_SERVERPORT  1883                   // use 8883 for SSL
#define AIO_USERNAME    "EloxFire"
#define AIO_KEY         "5428a62c41fb4f489eaca493f5e09f6d"

//Client wifi pour se connecter a MQTT
WiFiClient client;
Adafruit_MQTT_Client mqtt(&client, AIO_SERVER, AIO_SERVERPORT, AIO_USERNAME, AIO_KEY);

//FEEDS Publishing
Adafruit_MQTT_Publish ATEMP = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/airTemp");
Adafruit_MQTT_Publish AHUM = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/airHumidity");
Adafruit_MQTT_Publish SHUM = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soilHumidity");
Adafruit_MQTT_Subscribe ONOFF = Adafruit_MQTT_Subscribe(&mqtt, AIO_USERNAME "/feeds/onoff");

void MQTT_connect() {
  int8_t ret;

  // Stop if already connected.
  if (mqtt.connected()) {
    return;
  }

  Serial.print("Connecting to MQTT... ");

  uint8_t retries = 3;
  while ((ret = mqtt.connect()) != 0) { // connect will return 0 for connected
       Serial.println(mqtt.connectErrorString(ret));
       Serial.println("Retrying MQTT connection in 5 seconds...");
       mqtt.disconnect();
       delay(5000);  // wait 5 seconds
       retries--;
       if (retries == 0) {
         // basically die and wait for WDT to reset me
         while (1);
       }
  }
  Serial.println("MQTT Connected!");

  Adafruit_MQTT_Subscribe *subscription;
  while ((subscription = mqtt.readSubscription(5000))) {
    if (subscription == &ONOFF) {
      Serial.print(F("Got: "));
      Serial.println((char *)ONOFF.lastread);
    }
  }
  delay(5000);
}
