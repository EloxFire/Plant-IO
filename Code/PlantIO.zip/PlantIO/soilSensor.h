int sensor_pin = A0;
int currentSoilHumidity;

void readSoilSensor(){
  Serial.println("Soil Sensor Reading...\n");
  currentSoilHumidity = analogRead(sensor_pin);
  currentSoilHumidity = map(currentSoilHumidity, 1024, 515, 0, 100);
  Serial.print("Moisture : ");
  Serial.print(currentSoilHumidity);
  Serial.print("%\n");
  delay(5000);
}
